package miniproject;

public class Dobby_Totals_DTO {
	private int total_price; //주문 총 금액
	
	public Dobby_Totals_DTO() {
		
	}

	public int getTotal_totalprice() {
		return total_price;
	}

	public void setTotal_totalprice(int total_price) {
		this.total_price = total_price;
	}
	
}//end TotalsDTO




